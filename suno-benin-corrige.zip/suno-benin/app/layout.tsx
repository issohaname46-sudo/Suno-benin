import "./globals.css";

export const metadata = {
  title: "SUNO BÉNIN 🇧🇯 — IA qui chante",
  description: "Crée des chansons originales à partir de tes paroles avec SUNO BÉNIN.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
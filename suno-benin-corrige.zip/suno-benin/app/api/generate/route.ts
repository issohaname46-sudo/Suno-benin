import { NextRequest, NextResponse } from "next/server";

const API_BASE = "https://api.sunoapi.org/api/v1";

function getTaskId(payload: any): string | undefined {
  return payload?.taskId || payload?.data?.taskId || payload?.data?.task_id;
}

function extractTracks(payload: any) {
  const data = payload?.data || {};
  const response = data?.response || {};
  const list =
    response?.sunoData ||
    response?.data ||
    data?.sunoData ||
    data?.data ||
    [];

  if (!Array.isArray(list)) return [];

  return list.map((item: any) => ({
    id: item?.id,
    title: item?.title,
    audio_url: item?.audio_url || item?.audioUrl,
    audioUrl: item?.audioUrl,
    image_url: item?.image_url || item?.imageUrl,
    imageUrl: item?.imageUrl,
    duration: item?.duration,
  }));
}

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.SUNO_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "SUNO_API_KEY n'est pas configurée sur Vercel." },
        { status: 500 }
      );
    }

    const body = await req.json();
    const lyrics = String(body.lyrics || "").trim();
    const style = String(body.style || "").trim();
    const title = String(body.title || "Suno Bénin").trim();

    if (!lyrics) return NextResponse.json({ error: "Les paroles sont obligatoires." }, { status: 400 });
    if (lyrics.length > 3000) return NextResponse.json({ error: "Les paroles dépassent 3000 caractères." }, { status: 400 });
    if (style.length > 200) return NextResponse.json({ error: "Le style dépasse 200 caractères." }, { status: 400 });

    const response = await fetch(`${API_BASE}/generate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        prompt: lyrics,
        style,
        title: title.slice(0, 80),
        customMode: true,
        instrumental: false,
        model: process.env.SUNO_MODEL || "V4",
      }),
      cache: "no-store",
    });

    const data = await response.json();

    if (!response.ok || (data.code && data.code !== 200)) {
      return NextResponse.json(
        { error: data.msg || `Suno API a répondu HTTP ${response.status}.` },
        { status: response.status || 500 }
      );
    }

    const taskId = getTaskId(data);
    if (!taskId) {
      return NextResponse.json({ error: "Réponse Suno invalide : taskId manquant.", raw: data }, { status: 502 });
    }

    return NextResponse.json({ taskId });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Erreur serveur." },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  try {
    const apiKey = process.env.SUNO_API_KEY;
    if (!apiKey) return NextResponse.json({ error: "SUNO_API_KEY manquante." }, { status: 500 });

    const taskId = req.nextUrl.searchParams.get("taskId");
    if (!taskId) return NextResponse.json({ error: "taskId manquant." }, { status: 400 });

    const response = await fetch(
      `${API_BASE}/generate/record-info?taskId=${encodeURIComponent(taskId)}`,
      {
        headers: { Authorization: `Bearer ${apiKey}` },
        cache: "no-store",
      }
    );

    const data = await response.json();

    if (!response.ok || (data.code && data.code !== 200)) {
      return NextResponse.json(
        { error: data.msg || `Impossible de récupérer la tâche (HTTP ${response.status}).` },
        { status: response.status || 500 }
      );
    }

    return NextResponse.json({
      status: data?.data?.status || data?.status || "PENDING",
      tracks: extractTracks(data),
      message: data?.data?.errorMessage || data?.msg || "",
    });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Erreur serveur." },
      { status: 500 }
    );
  }
}
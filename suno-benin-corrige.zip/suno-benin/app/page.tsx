"use client";

import { useState } from "react";

type Track = {
  id?: string;
  title?: string;
  audio_url?: string;
  audioUrl?: string;
  image_url?: string;
  imageUrl?: string;
  duration?: number;
};

export default function Home() {
  const [lyrics, setLyrics] = useState(
    "Bonne semaine à ma Queen Rosalie, que Dieu te bénisse, tu es ma joie."
  );
  const [style, setStyle] = useState("Afrobeats Romantic, Female Voice, Slow");
  const [title, setTitle] = useState("Suno Bénin");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [tracks, setTracks] = useState<Track[]>([]);
  const [error, setError] = useState("");

  async function generate() {
    setLoading(true);
    setError("");
    setTracks([]);
    setStatus("Création de la chanson…");

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lyrics, style, title }),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Erreur pendant la génération.");

      const taskId = data.taskId;
      if (!taskId) throw new Error("L'API n'a pas retourné de taskId.");

      for (let i = 0; i < 24; i++) {
        await new Promise((r) => setTimeout(r, 5000));
        setStatus(`Génération en cours… ${Math.round(((i + 1) / 24) * 100)}%`);

        const check = await fetch(`/api/generate?taskId=${encodeURIComponent(taskId)}`, {
          cache: "no-store",
        });
        const result = await check.json();

        if (!check.ok) throw new Error(result.error || "Impossible de vérifier la tâche.");

        if (result.status === "SUCCESS" || result.tracks?.length) {
          setTracks(result.tracks || []);
          setStatus("🎉 Chanson prête !");
          return;
        }

        if (
          ["CREATE_TASK_FAILED", "GENERATE_AUDIO_FAILED", "CALLBACK_EXCEPTION", "SENSITIVE_WORD_ERROR"].includes(
            result.status
          )
        ) {
          throw new Error(result.message || `La génération a échoué (${result.status}).`);
        }
      }

      throw new Error("La génération prend plus de temps que prévu. Tu peux réessayer.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Une erreur inconnue est survenue.");
      setStatus("");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main>
      <div className="container">
        <h1>SUNO BÉNIN 🇧🇯</h1>
        <p className="subtitle">
          Transforme tes paroles en chanson avec une interface simple, rapide et pensée pour le public francophone.
        </p>

        <section className="card">
          <label htmlFor="title">Titre</label>
          <input id="title" value={title} maxLength={80} onChange={(e) => setTitle(e.target.value)} />

          <label htmlFor="lyrics">1. Tes paroles</label>
          <textarea
            id="lyrics"
            value={lyrics}
            maxLength={3000}
            onChange={(e) => setLyrics(e.target.value)}
            placeholder="Écris les paroles de ta chanson…"
          />
          <div className="small">{lyrics.length}/3000 caractères</div>

          <label htmlFor="style">2. Style de chant</label>
          <select id="style" value={style} onChange={(e) => setStyle(e.target.value)}>
            <option>Afrobeats Romantic, Female Voice, Slow</option>
            <option>Gospel Powerful, Piano, Emotional</option>
            <option>Rap Bénin Drill, Male Voice</option>
            <option>Afro Love, Amapiano</option>
            <option>Afrobeat, Male Voice, Dance, Energetic</option>
            <option>Acoustic Love, Female Voice, Emotional</option>
          </select>

          <button className="primary" onClick={generate} disabled={loading || !lyrics.trim()}>
            {loading ? "⏳ GÉNÉRATION…" : "🎤 FAIRE CHANTER"}
          </button>

          {status && <div className="status">{status}</div>}
          {error && <div className="status">❌ {error}</div>}

          {tracks.map((track, index) => {
            const audio = track.audio_url || track.audioUrl;
            const image = track.image_url || track.imageUrl;
            return (
              <div className="result" key={track.id || index}>
                {image && <img src={image} alt={track.title || `Chanson ${index + 1}`} />}
                <h2>{track.title || `Chanson ${index + 1}`}</h2>
                {audio ? (
                  <>
                    <audio controls src={audio} />
                    <a className="download" href={audio} target="_blank" rel="noreferrer">
                      📥 Ouvrir / télécharger
                    </a>
                  </>
                ) : (
                  <p className="small">Le lien audio n'est pas encore disponible.</p>
                )}
              </div>
            );
          })}
        </section>

        <a
          className="whatsapp"
          href="https://wa.me/2290196669448?text=Je%20veux%20un%20site%20comme%20Suno%20B%C3%A9nin"
          target="_blank"
          rel="noreferrer"
        >
          💬 Je veux un site comme celui-ci
        </a>

        <div className="footer">SUNO BÉNIN 🇧🇯 · Prototype Next.js / Vercel</div>
      </div>
    </main>
  );
}
# SUNO BÉNIN 🇧🇯

Application Next.js permettant d'envoyer des paroles à SunoAPI.org et de récupérer les chansons générées.

## Installation

```bash
npm install
cp .env.example .env.local
npm run dev
```

Ajoute ensuite ta clé dans `.env.local` :

```env
SUNO_API_KEY=ta_cle
SUNO_MODEL=V4
```

## Déploiement Vercel

1. Mets ce dossier dans GitHub.
2. Importe le dépôt dans Vercel.
3. Dans **Settings → Environment Variables**, ajoute `SUNO_API_KEY`.
4. Optionnel : ajoute `SUNO_MODEL=V4`.
5. Déploie.

## Important

La clé API ne doit jamais être placée dans `page.tsx` ni dans du code exécuté dans le navigateur.

L'API de génération est asynchrone : l'application récupère le `taskId`, puis interroge `record-info` jusqu'à obtenir le résultat.

Les fichiers générés par SunoAPI.org sont indiqués comme conservés pendant 15 jours dans leur documentation ; télécharge les créations importantes.

## Limites

La configuration V4 utilise un prompt de 3000 caractères maximum et un style de 200 caractères maximum selon la documentation SunoAPI.org.

## WhatsApp

Le bouton utilise le numéro fourni dans le projet :
+229 01 96 66 94 48
